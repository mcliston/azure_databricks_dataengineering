import duckdb
import pandas as pd
from typing import Any

class PerTeamExtract:
    """
    Class to extract data from parquet files located in Azure blob storage
    """
    def __init__(self, team_name:str, 
                 season_start:int, 
                 season_end:int,
                 abfs_obj:Any):
        """
        Extracts/Wrangles data from nba data located in Azure blob storage. 

        *note: storage_acct_name and storage_acct_key are required to initialize transaction between Databricks and Azure blob storage.
            These values can only be acquired within Azure Databricks.

        parameters:
        ---------------------------------
        team_name: str - name of team to subset by
        season_start: int - beginning year to subset by
        season_end: int - end year to subset by
        abfs_obj: Any - This object is initialized within Azure Databricks via adlfs.AzureBlobFileSystem class. The adlfs.AzureBlobFileSystem
                class accepts two parameters: account_name and account_key which are acquired via dbutils.secrets.get(scope=<name of scope>, key=<storage-acc-key>)

        returns
        ---------------------------------
        team_df: pd.DataFrame - DataFrame of general team stats over a given season
        team_picks_df: pd.DataFrame - DataFrame of team draft picks over a given season

        """
        self.team_name = team_name
        self.season_start = season_start
        self.season_end = season_end
        self.abfs = abfs_obj
        self.team_id = self._get_team_id()

    def query_parquet(self, q):

        with duckdb.connect() as conn:
            conn.register_filesystem(self.abfs)
            conn.execute("SET threads TO 16;")
            query = conn.sql(q)
            df = query.df()
        return df

    def _general_query(self, q) -> pd.DataFrame:
        """
        General query to the parquet files
        """

        query_result = self.query_parquet(q)
        return query_result

    def _get_team_id(self) -> pd.DataFrame:
        """
        Gets the team id from the team_details table.
        """
        table = 'team_details'
        q = f"""SELECT a.team_id
                    , a.nickname
                    , a.city
                    , a.headcoach
                    , a.abbreviation

                FROM read_parquet('abfs://data/{table}.parquet') AS a WHERE a.nickname = '{self.team_name}'"""

        team_df = self.query_parquet(q)

        assert len(team_df) == 1, f"Team {self.team_name} not found in team_details table."

        team_id = team_df.loc[team_df['nickname'] == self.team_name, 'team_id'].values[0]
        
        return team_id

    def _get_team_game_stats_df(self) -> pd.DataFrame:
        """
        Gets the team df from the team_details table.
        """

        assert self.team_id != None, "Team id not found."

        table = 'game_summary'
        table1 = 'other_stats'
        table2 = 'game'

        q = f"""

            WITH CTE_GAME_SUM AS (
                SELECT a.game_date_est
                    , substr(a.game_date_est, 1, 4) as season
                    , a.game_id
                    , a.home_team_id
                    , a.visitor_team_id
                    , a.season
                    , a.live_period
                    , b.season_id
                    , b.game_id
                    , b.wl_home
                    , b.min
                    , b.fgm_home
                    , b.fga_home
                    , b.fg_pct_home
                    , b.fg3m_home
                    , b.fg3a_home
                    , b.fg3_pct_home
                    , b.ftm_home
                    , b.fta_home
                    , b.ft_pct_home
                    , b.oreb_home
                    , b.dreb_home
                    , b.reb_home
                    , b.ast_home
                    , b.stl_home
                    , b.blk_home
                    , b.tov_home
                    , b.pf_home
                    , b.pts_home
                    , b.plus_minus_home
                    , b.wl_away
                    , b.fgm_away
                    , b.fga_away
                    , b.fg_pct_away
                    , b.fg3m_away
                    , b.fg3a_away
                    , b.fg3_pct_away
                    , b.ftm_away
                    , b.fta_away
                    , b.ft_pct_away
                    , b.oreb_away
                    , b.dreb_away
                    , b.reb_away
                    , b.ast_away
                    , b.stl_away
                    , b.blk_away
                    , b.tov_away
                    , b.pf_away
                    , b.pts_away
                    , b.plus_minus_away
                    

                    FROM read_parquet('abfs://data/{table}.parquet') AS a
                    LEFT JOIN (SELECT * FROM read_parquet('abfs://data/{table2}.parquet')) AS b ON a.game_id = b.game_id
                    WHERE a.home_team_id = {self.team_id} OR a.visitor_team_id = {self.team_id}

                    ),
                    CTE_TEAM_DETAILS AS (
                    SELECT *
                    FROM read_parquet('abfs://data/{table1}.parquet') AS a)

            

                SELECT * FROM (SELECT * FROM CTE_GAME_SUM AS aa WHERE aa.season >= '{self.season_start}' AND aa.season <= '{self.season_end}') AS c
                LEFT JOIN CTE_TEAM_DETAILS AS d ON c.game_id = d.game_id
                
        """

        teamDF = self.query_parquet(q)

        return teamDF

    def _get_team_draft_picks_per_season(self) -> pd.DataFrame:
        """
        Gets the team draft_picks from the draft_history table.
        """

        assert self.team_id != None, "Team id not found."

        table = 'draft_history'
        q = f"""
                WITH CTE_DRAFT AS (
                    SELECT *
                    FROM read_parquet('abfs://data/{table}.parquet') AS a WHERE a.team_id = {self.team_id}
                )
                SELECT * FROM CTE_DRAFT AS b WHERE b.season >= '{self.season_start-6}' AND b.season <= '{self.season_end}'
        """

        picksDF = self.query_parquet(q)

        return picksDF

    def run(self):
        team_df = self._get_team_game_stats_df()
        team_picks_df = self._get_team_draft_picks_per_season()

        return team_df, team_picks_df
